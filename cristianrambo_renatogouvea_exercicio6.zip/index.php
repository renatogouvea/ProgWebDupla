<?php

require 'includes/bootstrap.php'; 

new Ex4\app ();
