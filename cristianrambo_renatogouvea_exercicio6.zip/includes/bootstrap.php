<?php
session_name ('ex4');
session_start();

require 'controller/controle.php';
require 'includes/app.php';
require 'model/contato.php';
require 'model/ContatoFactory.php';