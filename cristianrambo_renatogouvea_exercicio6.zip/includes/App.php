<?php

namespace Ex4;

use controller\controle;

class app{
	public function __construct(){
		new controle();
	}

}
