<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Homepage</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    
</head>
<body>
    <div>
        <a href ="index.php?action=newContactForm">Cadastrar</a>
    </div>

	<div>
		<a href ="index.php?action=list">Exibir lista</a>
	</div>
</body>
</html>
