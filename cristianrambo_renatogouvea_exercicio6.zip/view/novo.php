<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Cadastro</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    
</head>
<body>
    <div>
        <form method="post" action="index.php?action=newContact" >
            <div><input type="text" name="name" placeholder="Nome" /></div>
            <div><input type="text" name="email" placeholder="Email" /></div>
            <div><input type="submit" value="Cadastrar"/></div>
        </form>
    </div>
</body>
</html>
